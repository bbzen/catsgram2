package test.java.ru.yandex.practicum.catsgram;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatsgramApplicationTests {

	@Test
	void contextLoads() {
	}

}
